import React, { useState } from "react";
import axios from "axios";
import "./WeatherCard.css";

const WeatherCard = () => {
  const [city, setCity] = useState("Islamabad");
  const [weather, setWeather] = useState(null);
  const [error, setError] = useState(null);
  const [loading, setLoading] = useState(false);

  const fetchWeather = async (cityName) => {
    if (!cityName) {
      setError("Please enter a city name.");
      return;
    }

    setLoading(true);
    setError(null);

    try {
      const { data } = await axios.get(
        `https://api.weatherapi.com/v1/current.json`,
        {
          params: {
            key: "5e4806a80d2541a0b6f115425250704",
            q: cityName,
          },
        }
      );
      setWeather(data);
    } catch (err) {
      setError("Could not fetch weather. Please try a different city.");
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    fetchWeather(city);
  };

 return (
  <div className="home-container">
<h1 className="app-title animated-title">
  Cloud<span className="highlight">See</span>ker

</h1>

    <form onSubmit={handleSubmit} className="search-form">
      <input
        type="text"
        placeholder="Enter city..."
        value={city}
        onChange={(e) => setCity(e.target.value)}
      />
      <button type="submit">Get Weather</button>
    </form>

    {error && <p className="error-message">{error}</p>}
    {loading && <p className="loading-message">Loading...</p>}
    
    {weather && !loading && (
      <div className="container">
        <h2>Weather in {weather.location.name}</h2>
        <h4>
          {weather.location.region}, {weather.location.country}
        </h4>
        <img
          src={`http:${weather.current.condition.icon}`}
          alt={weather.current.condition.text}
        />
        <p>
          <strong>{weather.current.temp_c}°C</strong>
        </p>
        <p>{weather.current.condition.text}</p>
      </div>
    )}
  </div>
);
}

export default WeatherCard;
